<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<meta name="robots" content="none" />
<title>404 Not Found</title>
<style>
*{font-family:"Microsoft Yahei";margin:0;font-weight:lighter;text-decoration:none;text-align:center;line-height:2.2em;}
html,body{height:100%;}
h1{font-size:100px;line-height:1em;}
table{width:100%;height:100%;border:0;}
</style>
</head>
<body>
<table cellspacing="0" cellpadding="0">
<tr>
<td>
<table cellspacing="0" cellpadding="0">
<tr>
<td>
<h3>客官不要。。呃。。呃。。呃呃呃。。。。</h3>
<p><img src=http://www.loner.fm/20160526091107.jpg width="30%" height="30%"/></p>
</td>
</tr>
</table>
</td>
</tr>
</table>
</body>
</html>