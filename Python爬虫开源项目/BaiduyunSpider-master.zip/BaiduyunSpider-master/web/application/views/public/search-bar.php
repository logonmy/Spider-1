<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div id="s-bar">
  <div class="container">
    <ul id="search-bar" class="nav nav-pills">
      <li><a href="http://www.whatsoo.com/search?from=tab&q=<?php echo $keyword ?>" class="web-s" >网页</a></li>
      <li><a href="#" class="pan-s active">网盘</a></li>
      <li><a href="http://www.whatsoo.com/search?from=tab&q=<?php echo $keyword ?>&type=bt" class="bt-s">BT磁力</a></li>
      <li><a href="http://www.whatsoo.com/search?from=tab&q=<?php echo $keyword ?>&type=pdf" class="pdf-s">电子书</a></li>
    </ul>
  </div>
</div>