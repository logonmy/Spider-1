<script>
var _hmt = _hmt || [];
(function(){
  var hm=document.createElement("script");
  hm.src="//hm.baidu.com/hm.js?97c7684bd37e85d04f1713fbd07aeab2";
  var s=document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1256142858'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1256142858' type='text/javascript'%3E%3C/script%3E"));</script>
