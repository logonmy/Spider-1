<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include dirname(__FILE__).'/xs/lib/XS.php';