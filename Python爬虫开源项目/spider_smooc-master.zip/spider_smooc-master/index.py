#!D:\Python27\python
# -*- coding: utf-8 -*-

from spider.spiderman import SpiderMan








if __name__=="__main__":
    spider = SpiderMan()
    spider.cmdshow_gbk()
    # spider.crawl("http://www.imooc.com/learn/110")