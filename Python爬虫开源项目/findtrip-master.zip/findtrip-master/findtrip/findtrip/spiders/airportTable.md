城市名	| 机场三字码 | 机场四字码 | 机场名称 | 英文名称
----|------|----|-----|-----
北京 | PEK | ZBAA | 北京首都国际机场 | BEIJING
上海 | SHA | ZSSS | 上海虹桥机场 | SHANGHAIHONGQIAO
上海 | PVG | ZSPD | 上海浦东机场 | SHANGHAIPUDONG
广州 | CAN | ZGGG | 广州白云机场 | GUANGZHOU
深圳 | SZX | ZGSZ | 深圳宝安国际机场 | SHENZHEN
成都 | CTU | ZUUU | 成都双流机场 | CHENGDU
厦门 | 	XMN | ZSAM | 厦门高崎机场 | XIAMEN
青岛 | TAO | ZSQD | 青岛流亭机场 | QINGDAO
... | ... | ... | ... | ...
查看更多,请访问http://airportcode.911cha.com/
