tbcrawler
=============
淘宝和天猫的爬虫,可以根据搜索关键词,物品id来抓去页面的信息.
db:MongoDB

tbcrawler
* 2 * * *  python /data/git/tbcrawler/crawler.py update
