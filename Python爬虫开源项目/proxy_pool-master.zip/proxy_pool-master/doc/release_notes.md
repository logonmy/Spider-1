## Release Notes

* newest
　　1.使用多线程验证useful_pool

* 1.10
　　1. 第一版；
　　2. 支持PY2/PY3;
　　3. 代理池基本功能；