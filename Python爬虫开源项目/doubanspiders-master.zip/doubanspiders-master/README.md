doubanspiders
=============

豆瓣电影、书籍、小组、相册、东西等爬虫集 writen by Python.

PS: 哎, 八个月后自己尝试设计了下爬虫框架, 感觉doubanspiders代码简直糟蹋了Scrapy, 阿弥陀佛!

###依赖服务
1. MongoDB

###依赖包
1. pip install scrapy
2. pip install pybloom
3. pip install pymongo

###运行豆瓣电影爬虫
1. 进入douban/movie目录
2. 执行scrapy crawl movie

###运行豆瓣相册爬虫
1. 进入douban/album目录
2. 执行scrapy crawl album
