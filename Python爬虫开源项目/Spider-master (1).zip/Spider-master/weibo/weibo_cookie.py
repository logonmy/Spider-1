# Cookies List

# chnqutan@126.com
# 28292469
# browser : Microsoft Edge
weiboCookies0 = {"Cookie": r'_T_WM=c11b114d16154e6b199c86bde933a8ec; '
                           r'SUHB=0V5UuzbbfDBQcM; '
                           r'SUB=_2A257iAlqDeTxGeNJ6lUZ8CfKwziIHXVZcpcirDV6PUJbrdAKLUf4kW1UNlXkecE9mnCLeeUFispRtI6DvQ..; '
                           r'gsid_CTandWM=4uV8f82117MRA4qcqd3KxnZsJb2'}

# chnqutan@126.com
# 28292469
# browser : Chrome
# weiboCookies0 = {"Cookie": r' _T_WM=94747580e19faea2f7262935e5065e9a; '
#                            r'SUHB=0KAhAo8fdcywIg; '
#                            r'SUB=_2A257iOw9DeTxGeNJ6lUZ8CfKwziIHXVZcvR1rDV6PUJbrdANLWnTkW1sUCe94rvRvBkOKmA2C2w2I7VjOg..; '
#                            r'gsid_CTandWM=4ugT61ad1EuHwStthcJnEnZsJb2'}

# truemanqu@126.com
# 28292469
# browser : Microsoft Edge
weiboCookies1 = {"Cookie": r'_T_WM=94747580e19faea2f7262935e5065e9a; '
                           r'SUHB=0d4u1kDzrWqdMG; '
                           r'SUB=_2A257iAOUDeSRGeNJ6VEQ8y7KyTWIHXVZcq3crDV6PUJbrdAKLW6jkW0Do8gVBEU-l1vipvAHav79DYUr4A..; '
                           r'gsid_CTandWM=4uBh61ad1Iw3edGqr0zTUo0Qya9'}
# iequtan@163.com
# 28292469taN
# browser: Chrome
weiboCookies2 = {"Cookie": r'_T_WM=2948cd4c94cfc4a68f945e26493e29b7; '
                           r'SUB=_2A257lN5TDeTxGeNG6VAV8yjLzz-IHXVZduIbrDV6PUJbrdANLVWhkW1LHetQf3cPwexH3PgDn0LhI5M6UJQqIA..;'
                           r'gsid_CTandWM=4uYlcce81LNCqxlf6uX8boqGgbZ'}

weiboCookies = [weiboCookies0 , weiboCookies1, weiboCookies2]
