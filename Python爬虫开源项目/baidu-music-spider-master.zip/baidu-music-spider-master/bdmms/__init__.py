__doc__ = '**bdmms** means: **Baidu Mp3 Metadata Spider** '
